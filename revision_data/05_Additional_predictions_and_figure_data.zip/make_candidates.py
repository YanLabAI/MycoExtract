from pathlib import Path
from Bio import SeqIO
import json
OUT=Path(__file__).resolve().parent
seq={r.id:str(r.seq) for r in SeqIO.parse(OUT/'sources/candidate_accessions.fasta','fasta')}
for p in (OUT/'sources').glob('*.fasta'):
 if p.name=='candidate_accessions.fasta':continue
 for r in SeqIO.parse(p,'fasta'):seq[r.id]=str(r.seq)
rows=[]
def add(name,acc,group,doi,year,substrate='Zearalenone',values=None,notes='',mut=None,status='primary'):
 s=seq[acc]
 if mut:
  s=list(s)
  for old,pos,new in mut:
   assert s[pos-1]==old,(name,pos,s[pos-1]);s[pos-1]=new
  s=''.join(s)
 rows.append(dict(enzyme=name,accession=acc,group=group,doi=doi,year=year,substrate=substrate,
                  sequence=s,values=values or {},notes=notes,status=status))
# All nine soluble, catalytically characterized ZenA homologues in Table 1;
# insoluble homologues have no measured kinetics and are not scored.
zen=[('ZenA_Re','AYJ13169.1',.34,2.924),('ZenA_Ku','AHH94730.1',3.02,1.972),
 ('ZenA_Sv','YP_004810515.1',.52,2.156),('ZenA_Sl','WP_003971353.1',2.99,.712),
 ('ZenA_Scfl','WP_007388500.1',1.05,1.230),('ZenA_Rt','WP_007530102.1',.14,.169),
 ('ZenA_Nb','YP_006808627.1',11.33,.007),('ZenA_Mg','YP_001134273.1',6.01,.003),
 ('ZenA_Ge','WP_007315861.1',17.60,.024)]
for name,acc,km,kcat in zen:
 add(name,acc,'ZenA_2024','10.1021/acscatal.4c00271',2024,values={'Km_uM':km,'kcat_s':kcat},
     notes='Primary Table 1 (image transcribed); temperatures/pH differ by enzyme. Efficiency not separately reported and not fabricated.')
mw=318.369
for name,km,kcat,eff,mut in [('ZHRnZ_WT',21.51,.00242,1.13e-4,None),
 ('ZHRnZ_E122Q',86.38,.00741,.86e-4,[('E',122,'Q')]),
 ('ZHRnZ_E122R',8.123,.001202,1.48e-4,[('E',122,'R')])]:
 add(name,'GAP90066.2','ZHRnZ_2024','10.3390/ijms25179665',2024,
     values={'Km_uM':km*1000/mw,'kcat_s':kcat,'kcat_Km_M_s':eff*mw*1000},mut=mut,
     notes='Table 3; mass-based Km and efficiency converted using the same ZEN MW as original training. Mutants reconstructed from explicitly named positions.')
add('ZPH1101','AFQ59371.1','ZPH1101_2025','10.3390/toxins17010021',2025,
    values={'Km_uM':18.18,'kcat_s':54.69},notes='Article reports 100% identity with AFQ59371; two numerical parameters reported directly. Phosphorylation rather than hydrolysis.')
add('Cr2zen','ACW19936.1','Cr2zen_2026','10.3390/toxins18010010',2026,
    values={'Km_uM':75.9},notes='Km only; stated efficiency has inconsistent dimensions and is not scored. Accession is 98.48% identical to ZHD101 according to article; not an unseen-family test.')
add('MgSDR1','XP_001483215.1','MgSDR1_2025','10.1002/advs.202501146',2025,substrate='Patulin',
    values={'Km_uM':1420,'kcat_s':.0123,'kcat_Km_M_s':8.66},
    notes='SI Table S5. Figure 3A prints NP_001483215.1, which is invalid; XP_001483215.1 matches the illustrated alignment, 290-aa length, cloning primer MSLR, and S174/Y188/K192. Reference sequence mapping correction is disclosed; exact experimental strain sequence not deposited.',status='reference_sequence_proxy')
add('ZenR','WP_081559690.1','ZenR_2023','10.3390/toxins15120688',2023,
    values={'Km_uM':21.14},notes='Full-text accession explicitly identifies tested enzyme; Km only; Vmax is not treated as kcat.')
add('ZENM','RYP08044.1','ZENM_2026','10.1016/j.pep.2025.106843',2026,
    values={'Km_uM':21.59},notes='2026 abstract reports Km; sequence accession traced through earlier literature. Exact expressed construct not verified from accessible full text.',status='reference_sequence_proxy')
# Preserve the original two cases rather than replacing adverse results.
old=json.loads((OUT.parent/'sources/external_check_provenance.json').read_text(encoding='utf8'))
for c in old['candidates']:
 rows.append(dict(enzyme=c['enzyme'],accession=c['accession'],group='DON_2026',doi=old['source_doi'],year=2026,
                  substrate='Deoxynivalenol',sequence=c['sequence'],values={k:c[k] for k in ['Km_uM','kcat_s','kcat_Km_M_s']},
                  notes='Previously tested cases, retained in expanded ledger.',status='primary'))
# Second search pass: preserve every measured parameter in the newly retrieved
# two-member study, and the only patulin kinetic construct in the 2026 study.
if 'XP_013255140.1' in seq:
 for name,km,kcat,eff,mut in [('ZHDAY3_WT',90.50,9.28,.10,None),('ZHDAY3_N153H',76.28,12.3,.17,[('N',153,'H')])]:
  add(name,'XP_013255140.1','ZHDAY3_2024','10.1128/aem.01818-23',2024,substrate='alpha-zearalanol',
      values={'Km_uM':km,'kcat_s':kcat,'kcat_Km_M_s':eff*1e6},mut=mut,
      notes='Primary Table 3, publisher HTML and PMC indexed full text. The primary article explicitly gives XP_013255140.1 and 264 residues. Substrate is alpha-zearalanol, not ZEN. N153H reconstructed with residue check. PDB deposition 8JLV is the inactive S102A structural construct and is not used as the kinetic WT sequence.')
from docx import Document
supp=OUT/'sources/AsPLa_supp/PRO-35-e70729-s001.docx'
if supp.exists():
 paragraphs=[p.text.strip() for p in Document(supp).paragraphs]
 index=next(i for i,p in enumerate(paragraphs) if p.startswith('AsPLa-D protein sequence'))
 s=next(p for p in paragraphs[index+1:] if p and set(p)<=set('ACDEFGHIKLMNPQRSTVWY'))
 rows.append(dict(enzyme='AsPLa_D',accession='Author SI designed sequence',group='AsPLa_2026',doi='10.1002/pro.70729',year=2026,
  substrate='Patulin',sequence=s,values={'Km_uM':90.,'kcat_s':.97,'kcat_Km_M_s':1.1e4},
  notes='Author SI engineered protein sequence; native accession is not substituted for the designed variant. Measurements used an MBP fusion; features encode catalytic domain as in original enzyme mapping, so construct dependence is unresolved.',status='construct_domain_only'))
(OUT/'candidates.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf8')
(OUT/'analysis_protocol.md').write_text('''# Expanded external retrospective check

Search date 2026-10-25. Scope broadened to mycotoxin-converting enzymes published in 2023–2026, prioritizing 2025–2026 and admitting older studies absent from original training. This is a targeted search with full-text eligibility checks, not an exhaustive systematic review.

Freeze the original feature definitions, training records, StandardScaler and Ridge alpha=10. No candidate-driven model or hyperparameter selection. Include all retrievable measured enzymes in each selected paper, not just favorable predictions. Do not infer kcat from specific activity or Vmax. Do not create a reported efficiency by dividing other reported parameters. Native proteins and explicit mutants may be scored; immobilized systems and unresolved constructs are separated. Exact training-sequence matches are excluded from unseen-sequence rankings. Reference-sequence proxies are reported separately.

Before executing the expanded predictions, use mean absolute log10 error for kcat and Km jointly to rank complete two-target enzyme cases, and the corresponding paper-level mean over all such enzymes to rank whole studies. Report individual target errors and training-mean baseline. At least three measured enzymes with both targets are required to describe a multi-enzyme group. Keep one-target cases and independently regressed efficiency as separate results; no selection of whichever target looks best. A geometric error factor is 10 to the mean absolute log10 error; it is not a percent accuracy. A best observed case/group is selected after evaluation and cannot estimate generalization performance. Predictions do not prove catalytic function, detoxification, or prospective discovery.
''',encoding='utf8')
print('Candidates',len(rows),'reported parameter instances',sum(len(x['values']) for x in rows))
