from pathlib import Path
import urllib.request, concurrent.futures, zipfile, io, json
OUT=Path(__file__).resolve().parent/'sources'
items={'AsPLa':'PMC13413597'}
def fetch(item):
 name,pmc=item; url=f'https://www.ebi.ac.uk/europepmc/webservices/rest/{pmc}/supplementaryFiles'
 try:
  raw=urllib.request.urlopen(url,timeout=50).read(); (OUT/(name+'_supplements.zip')).write_bytes(raw)
  files=[]
  with zipfile.ZipFile(io.BytesIO(raw)) as z:
   for n in z.namelist():
    if n.endswith('/') or not n.lower().endswith(('.jpg','.png','.webp','.pdf','.docx','.zip','.fasta','.txt','.xlsx')):continue
    p=OUT/(name+'_supp')/Path(n).name;p.parent.mkdir(exist_ok=True)
    p.write_bytes(z.read(n));files.append(p.name)
  return dict(name=name,url=url,bytes=len(raw),files=files)
 except Exception as e:return dict(name=name,url=url,error=str(e))
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:r=list(ex.map(fetch,items.items()))
(OUT/'supplement_retrieval.json').write_text(json.dumps(r,indent=2),encoding='utf8')
print(json.dumps(r,indent=2))
