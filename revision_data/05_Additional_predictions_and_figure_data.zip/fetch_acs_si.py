from pathlib import Path
import urllib.request,json,concurrent.futures
OUT=Path(__file__).resolve().parent/'sources'
def fetch(doi):
 try:
  req=urllib.request.Request('https://api.figshare.com/v2/articles?resource_doi='+doi)
  items=json.load(urllib.request.urlopen(req,timeout=30))
  matches=[x for x in items if doi in str(x)]
  if not matches:
   req=urllib.request.Request('https://api.figshare.com/v2/articles/search',data=json.dumps({'search_for':doi,'limit':10}).encode(),headers={'Content-Type':'application/json'})
   items=json.load(urllib.request.urlopen(req,timeout=30));matches=[x for x in items if doi in str(x)]
  results=[]
  for x in matches:
   detail=json.load(urllib.request.urlopen('https://api.figshare.com/v2/articles/'+str(x['id']),timeout=30))
   (OUT/(str(x['id'])+'_figshare.json')).write_text(json.dumps(detail,indent=2),encoding='utf8')
   for f in detail.get('files',[]):
    b=urllib.request.urlopen(f['download_url'],timeout=40).read();(OUT/f['name']).write_bytes(b);results.append((f['name'],len(b)))
  return dict(doi=doi,matches=len(matches),files=results)
 except Exception as e:return dict(doi=doi,error=str(e))
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:print(json.dumps(list(ex.map(fetch,['10.1021/acs.jafc.6c04812','10.1021/acs.jafc.5c05633'])),indent=2))
