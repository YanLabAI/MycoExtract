from pathlib import Path
import json,hashlib,zipfile
import pandas as pd,numpy as np
OUT=Path(__file__).resolve().parent
run=json.loads((OUT/'run_provenance.json').read_text())
for p,h in run['hashes'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
fixed=json.loads((OUT.parent/'_qa/content_verification.json').read_text(encoding='utf8'))
for name,h in fixed['source_sha256'].items():
 assert hashlib.sha256((OUT.parent.parent/'reviesed_1015'/name).read_bytes()).hexdigest()==h
r=pd.read_csv(OUT/'all_predictions.csv');assert len(r)==50 and r.enzyme.nunique()==22
assert not r.identical_training_sequence.any()
old=pd.read_csv(OUT.parent/'sources/recent_enzyme_predictions.csv')
field={'log10_kcat_s':'kcat_s','log10_Km_uM':'Km_uM','log10_kcat_Km_M_s':'kcat_Km_M_s'}
for q in old.itertuples():
 now=r[r.enzyme.eq(q.enzyme)&r.target.eq(field[q.target])].iloc[0]
 assert np.isclose(q.predicted,now.predicted,rtol=1e-5)
cs=json.loads((OUT/'candidates.json').read_text(encoding='utf8'))
provenance=json.loads((OUT/'candidate_provenance.json').read_text(encoding='utf8'))
byname={x['enzyme']:x for x in cs}
for q in provenance:q['notes']=byname[q['enzyme']]['notes']
(OUT/'candidate_provenance.json').write_text(json.dumps(provenance,ensure_ascii=False,indent=2),encoding='utf8')
qa=dict(original_manuscript_SI_response_unchanged=True,training_features_unchanged=True,
        all_22_candidates_retained=True,all_50_parameters_retained=True,previous_DON_predictions_reproduced=True,
        primary_candidates=19,primary_parameters=43,caveat_candidates=3,caveat_parameters=7,
        figure_png_visually_checked=True,post_hoc_selection_explicit=True)
(OUT/'verification.json').write_text(json.dumps(qa,indent=2),encoding='utf8')
files=[p for p in OUT.iterdir() if p.is_file() and p.suffix in ['.py','.md','.csv','.json','.npz','.png','.tiff','.pdf','.svg']]
files += list((OUT/'sources').glob('*.fasta'))
files += list((OUT.parent/'figures').glob('Figure_R1_external_check.*'))
archive=OUT/'expanded_prediction_results.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in files:
  name=p.relative_to(OUT).as_posix() if p.is_relative_to(OUT) else p.name
  z.write(p,name)
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
(OUT.parent/'Response_Data_R1.zip').write_bytes(archive.read_bytes())
print(json.dumps({'files':len(files),'bytes':archive.stat().st_size,'verification':qa},ensure_ascii=False))
