# Additional predictions and figure source data

This archive accompanies the 29 October revision of MycoExtract. It supplements
the three data workbooks and analysis archive in the repository's revision_data
directory. The reported numerical results and existing artwork are unchanged.

## Additional retrospective comparison

all_predictions.csv retains all 50 reported measurements from 22 enzymes or
variants. The primary subset contains 43 measurements from 19 candidates with
verified sequence and construct assignments; seven measurements have flags.
Figure S5 displays all 17 primary kcat and 19 primary Km cases. All seven primary
predictions within twofold are highlighted after evaluation. Interpretation is
specific to the evaluated targets and enzyme–substrate combinations.

## Fold distributions and SI presentation

Figures S6 and S7 display five fold values per group. The duplicated fold-by-fold
presentation tables were removed from the SI. All of their information is retained:

| File | Contents |
|---|---|
| Figure_S6_fold_metrics.csv | 15 plotted fixed-Ridge fold results, three grouping schemes. |
| Figure_S7_outer_fold_metrics.csv | 15 plotted nested outer-fold results, three kinetic targets. |
| Fixed_Ridge_fold_and_pooled_metrics.csv | All 18 rows formerly shown in Table S8, including pooled rows. |
| Nested_outer_fold_details.csv | All 15 rows formerly shown in Table S9, including selected models. |

The retained Tables S6 and S7 provide pooled and summary metrics, respectively.
The current Tables S8, S9 and S10 report the numerical audit, field evaluation
and joint holdout. These are separate from the fold-distribution figures.
Folds describe evaluation variability and are not independent biological replicates.

## Reproduction

Extract this archive into revision_data/additional_predictions, beside the
three workbooks and 04_Analysis_scripts.zip. With numpy, pandas, openpyxl,
scikit-learn and matplotlib installed, run:

```bash
python reproduce_additional_predictions.py --revision-data ..
python plot_model_results.py
python plot_S5.py
```

The first command refits the fixed StandardScaler + Ridge(alpha=10) model using
the frozen training features in 04_Analysis_scripts.zip and candidate features
in external_features.npz. It checks all 50 predictions against the released
values. No model API or embedding download is needed for this verification.
Plot outputs are written to reproduced_figures; original artwork is retained.
The historical run_predictions.py records how candidate features were originally
generated; it contains original workstation paths. Use the portable verification
script above to reproduce the released predictions from frozen features.
The verification allows an absolute difference of 1e-4 on the log10 scale for
float32 numerical solver variation across software versions (less than 0.024%
on the original scale). It also requires unchanged twofold classifications.
The released all_predictions.csv is never overwritten by this verification.

## Provenance

Candidate sequences, source assignments, screening decisions, flags, complete
rankings and historical retrieval/analysis scripts are retained. Source article
PDFs are not included. The PDF files in this archive are generated result plots.
Historical notes may use earlier table identifiers; the current mapping is given
above. No new experiment, curve extraction or model selection was performed.
