from pathlib import Path
import os,json,hashlib
OUT=Path(__file__).resolve().parent
os.environ['TORCH_HOME']=str(OUT.parent/'_qa/torch')
import numpy as np,pandas as pd,torch,esm
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from rdkit import Chem,DataStructs
from rdkit.Chem import AllChem,Descriptors
from Bio.Align import PairwiseAligner

MODEL=Path(r'D:/Doc_Projects/MycoExtract/MycoExtract/article_521/article_version1/modeling')
data_path=MODEL/'data/kinetic_modeling_dataset.csv';feature_path=MODEL/'features/feature_matrix.npz'
hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [data_path,feature_path]}
df=pd.read_csv(data_path);X=np.load(feature_path)['X'];assert X.shape==(72,1514)
candidates=json.loads((OUT/'candidates.json').read_text(encoding='utf8'))
torch.set_num_threads(4);encoder,alphabet=esm.pretrained.esm2_t12_35M_UR50D();encoder.eval();bc=alphabet.get_batch_converter()
def embed(seqs):
 _,_,tok=bc([(str(i),s[:1022]) for i,s in enumerate(seqs)])
 with torch.no_grad():h=encoder(tok,repr_layers=[12],return_contacts=False)['representations'][12]
 return np.vstack([h[i,1:len(s[:1022])+1].mean(0).numpy() for i,s in enumerate(seqs)])
assert np.max(np.abs(embed([df.sequence.iloc[0]])[0]-X[0,:480]))<1e-4
emb=[]
for i in range(0,len(candidates),4):
 emb.extend(embed([r['sequence'] for r in candidates[i:i+4]]));print('Embedded',min(i+4,len(candidates)),flush=True)
fns=[Descriptors.MolWt,Descriptors.MolLogP,Descriptors.TPSA,Descriptors.NumHAcceptors,
 Descriptors.NumHDonors,Descriptors.NumRotatableBonds,Descriptors.RingCount,
 Descriptors.FractionCSP3,Descriptors.NumAromaticRings,Descriptors.HeavyAtomCount]
test=[]
aligner=PairwiseAligner(mode='global',match_score=1,mismatch_score=-1,open_gap_score=-10,extend_gap_score=-.5)
for c,e in zip(candidates,emb):
 source=df[df.substrate.str.lower().eq(c['substrate'].lower())].iloc[0]
 m=Chem.MolFromSmiles(source.substrate_smiles_canonical);arr=np.zeros(1024,dtype=np.float32)
 DataStructs.ConvertToNumpyArray(AllChem.GetMorganFingerprintAsBitVect(m,2,nBits=1024),arr)
 mol=np.r_[arr,np.array([f(m) for f in fns],dtype=np.float32)]
 assert np.max(np.abs(mol-X[source.name,480:]))<1e-4
 test.append(np.r_[e,mol]);c['identical_training_sequence']=c['sequence'] in set(df.sequence)
 best=0
 for s in sorted(set(df.sequence)):
  a=aligner.align(c['sequence'],s)[0];best=max(best,a.counts().identities/min(len(s),len(c['sequence'])))
 c['max_training_identity_shorter_denominator']=float(best)
test=np.asarray(test);np.savez(OUT/'external_features.npz',X=test)
rows=[]
for target,field in [('log10_kcat_s','kcat_s'),('log10_Km_uM','Km_uM'),('log10_kcat_Km_M_s','kcat_Km_M_s')]:
 valid=df[target].notna().to_numpy();y=df.loc[valid,target].to_numpy(float)
 model=make_pipeline(StandardScaler(),Ridge(alpha=10.));model.fit(X[valid],y);pred=model.predict(test);baseline=float(y.mean())
 for c,prediction in zip(candidates,pred):
  if field not in c['values']:continue
  truth=float(c['values'][field]);error=abs(float(prediction)-np.log10(truth));baseline_error=abs(baseline-np.log10(truth))
  rows.append(dict(enzyme=c['enzyme'],accession=c['accession'],group=c['group'],doi=c['doi'],year=c['year'],substrate=c['substrate'],status=c['status'],
   target=field,observed=truth,predicted=10**float(prediction),observed_log10=float(np.log10(truth)),predicted_log10=float(prediction),
   absolute_log10_error=error,fold_error=10**error,baseline_predicted=10**baseline,baseline_absolute_log10_error=baseline_error,baseline_fold_error=10**baseline_error,
   identical_training_sequence=c['identical_training_sequence'],max_training_identity=c['max_training_identity_shorter_denominator']))
r=pd.DataFrame(rows);r.to_csv(OUT/'all_predictions.csv',index=False)
(OUT/'candidate_provenance.json').write_text(json.dumps(candidates,ensure_ascii=False,indent=2),encoding='utf8')
complete=r[r.target.isin(['kcat_s','Km_uM'])].groupby('enzyme').filter(lambda x:len(x)==2)
rank=complete.groupby(['enzyme','group','status','identical_training_sequence']).agg(mean_abs_log10_error=('absolute_log10_error','mean'),baseline_mae=('baseline_absolute_log10_error','mean'),max_fold_error=('fold_error','max'),max_training_identity=('max_training_identity','first')).reset_index()
rank['geometric_fold_error']=10**rank.mean_abs_log10_error;rank['baseline_geometric_fold_error']=10**rank.baseline_mae
rank.sort_values('mean_abs_log10_error').to_csv(OUT/'complete_case_rankings.csv',index=False)
groups=complete.groupby('group').agg(enzymes=('enzyme','nunique'),parameter_instances=('enzyme','size'),mean_abs_log10_error=('absolute_log10_error','mean'),baseline_mae=('baseline_absolute_log10_error','mean'))
groups['geometric_fold_error']=10**groups.mean_abs_log10_error;groups['baseline_geometric_fold_error']=10**groups.baseline_mae
groups.sort_values('mean_abs_log10_error').to_csv(OUT/'whole_study_rankings.csv')
for p,h in hashes.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h
(OUT/'run_provenance.json').write_text(json.dumps(dict(model='Original StandardScaler + fixed Ridge alpha=10',hashes=hashes,candidates=len(candidates),parameters=len(rows),training_unchanged=True),indent=2),encoding='utf8')
print(rank.sort_values('mean_abs_log10_error').to_string(index=False),flush=True)
print(groups.sort_values('mean_abs_log10_error').to_string(),flush=True)
print(r[['enzyme','target','observed','predicted','fold_error','baseline_fold_error']].to_string(index=False),flush=True)
