# Expanded prediction figure

Core conclusion: favorable predictions exist for selected individual parameters, while the same enzymes have substantial errors on other targets and broader performance is heterogeneous.

Archetype: quantitative grid. Python backend, following the saved preference. Panel a is the main evidence: kcat and Km error factors for every candidate with both measured targets, without excluding adverse cases. Proxy sequences and construct-dependent cases are marked with an asterisk. Panel b shows all nine ZenA kcat predictions and the baseline; the two closest cases are highlighted as selected after evaluation. Panel c shows all three reported targets for both ZHDAY3 variants against alpha-zearalanol; close Km values do not imply close kcat or efficiency values.

Export: 183 mm width; editable PDF/SVG, PNG/TIFF at 600 dpi. All observations are measured literature parameters and deterministic predictions; no synthetic data, replicates, confidence intervals or significance tests. Error factor is max(predicted/observed, observed/predicted). The 2-fold guide is descriptive and not a predefined success criterion. The source is all_predictions.csv. Do not treat selected examples as an unbiased performance estimate. Original training and manuscript/SI remain unchanged.
