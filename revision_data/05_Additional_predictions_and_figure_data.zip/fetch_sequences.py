from pathlib import Path
import urllib.request, json, xml.etree.ElementTree as ET, time
OUT=Path(__file__).resolve().parent/'sources'
ids=['GAP90066.2','KFL25551.1','AFQ59371.1','ACW19936.1','NP_001483215.1','AYJ13169','AHH94730',
     'YP_004810515','WP_003971353','WP_007388500','WP_007530102','YP_006808627','YP_001134273','WP_007315861']
url='https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=protein&id='+','.join(ids)+'&rettype=fasta&retmode=text'
try:
 raw=urllib.request.urlopen(url,timeout=45).read();(OUT/'candidate_accessions.fasta').write_bytes(raw)
 print('FASTA',len(raw),raw[:80])
except Exception as e:print('FASTA error',str(e))
for name,query in [('ZPH1101','DOI:10.3390/toxins17010021'),('ZenR','EXT_ID:38133192 AND SRC:MED')]:
 url='https://www.ebi.ac.uk/europepmc/webservices/rest/search?query='+urllib.parse.quote(query)+'&format=json'
 try:
  data=json.load(urllib.request.urlopen(url,timeout=30));(OUT/(name+'_metadata.json')).write_text(json.dumps(data,indent=2),encoding='utf8')
  for rec in data['resultList']['result']:
   print(name,rec.get('pmcid'),rec.get('title'))
   if rec.get('pmcid'):
    raw=urllib.request.urlopen(f'https://www.ebi.ac.uk/europepmc/webservices/rest/{rec["pmcid"]}/fullTextXML',timeout=30).read();(OUT/(name+'.xml')).write_bytes(raw)
 except Exception as e:print(name,str(e))
