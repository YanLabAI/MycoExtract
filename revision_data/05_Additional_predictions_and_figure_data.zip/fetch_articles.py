from pathlib import Path
import concurrent.futures, json, urllib.request, xml.etree.ElementTree as ET

OUT=Path(__file__).resolve().parent
(OUT/'sources').mkdir(parents=True,exist_ok=True)
articles={'ZHD30L':'PMC13517648','ZHRnZ':'PMC11395237','ZenA':'PMC10913051',
          'DDE':'PMC12737667','MgSDR1':'PMC12225012','AMH2102':'PMC12944703',
          'MbAmh1':'PMC12147602','Cr2zen':'PMC12846278','ZENG_free':'PMC13211546'}
def fetch(item):
    name,pmc=item
    url=f'https://www.ebi.ac.uk/europepmc/webservices/rest/{pmc}/fullTextXML'
    try:
        raw=urllib.request.urlopen(url,timeout=45).read()
        root=ET.fromstring(raw)
        (OUT/'sources'/f'{name}.xml').write_bytes(raw)
        lines=[]
        for el in root.iter():
            if el.tag in ['article-title','p','table-wrap','supplementary-material']:
                lines.append(' '.join(''.join(el.itertext()).split()))
        (OUT/'sources'/f'{name}.txt').write_text('\n\n'.join(lines),encoding='utf8')
        refs=[(el.tag,el.attrib) for el in root.iter() if any('href' in k for k in el.attrib)]
        (OUT/'sources'/f'{name}_links.json').write_text(json.dumps(refs,ensure_ascii=False,indent=2),encoding='utf8')
        return dict(name=name,pmc=pmc,url=url,bytes=len(raw),status='downloaded')
    except Exception as e:return dict(name=name,pmc=pmc,url=url,status=str(e))
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool: results=list(pool.map(fetch,articles.items()))
(OUT/'retrieval_log.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(results,ensure_ascii=False,indent=2))
