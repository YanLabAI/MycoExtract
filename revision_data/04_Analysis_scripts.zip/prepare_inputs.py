from pathlib import Path
import shutil
import pandas as pd
HERE=Path(__file__).resolve().parent
DATA=HERE.parent
if not (DATA/'01_Database.xlsx').exists(): DATA=HERE
for folder in ['data','dataset','features','validation/record_evaluation','validation/document_evaluation','validation/field_and_source_audit','reviewer_revision_20261007']:(HERE/folder).mkdir(parents=True,exist_ok=True)
mapping=[
('01_Database.xlsx','Records','dataset/mycoextract_primary_database_v20260530_reviewed.csv'),
('03_Kinetic_modelling.xlsx','Measurements','data/kinetic_modeling_dataset.csv'),
('02_Extraction_validation.xlsx','Record_scores','validation/record_evaluation/per_paper_ledger.csv'),
('02_Extraction_validation.xlsx','Document_scores','validation/document_evaluation/per_publication_document_ledger.csv'),
('02_Extraction_validation.xlsx','Six_fields','validation/field_and_source_audit/six_field_scores.csv'),
('02_Extraction_validation.xlsx','Numerical_source_checks','validation/field_and_source_audit/numerical_source_audit.csv'),
('03_Kinetic_modelling.xlsx','Nested_predictions','reviewer_revision_20261007/nested_all_targets_20261010_oof_predictions.csv')]
for book,sheet,dest in mapping:pd.read_excel(DATA/book,sheet_name=sheet).to_csv(HERE/dest,index=False,encoding='utf-8-sig')
shutil.copy2(HERE/'feature_matrix.npz',HERE/'features/feature_matrix.npz')
print('Prepared inputs from the three workbooks.')
