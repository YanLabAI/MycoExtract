Extract this archive into a folder named analysis beside the three XLSX files.
Run: python prepare_inputs.py
Then: python reproduce_summary.py
To refit the supplied analyses, run reanalyse_existing_data.py,
nested_all_targets_20261010.py, or joint_unseen_cluster_substrate_20261010.py.
Frozen features are supplied to avoid repeating the protein embedding calculation.
The original analysis logic is retained; input paths are made local to this folder.
Extraction prompts, biological rules and extraction code are in the main repository.
